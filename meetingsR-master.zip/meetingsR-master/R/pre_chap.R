url = 'https://github.com/jumpingrivers/meetingsR/blob/master/'
gh_edit_path = paste0(url, knitr::current_input())
#
edit_btn = paste0('<a href="', gh_edit_path,
                  '" class = "h2-side-link">',
                  '<img src="https://bit.ly/2RRirG7" ',
                  'alt="fa-edit" ',
                  'class="edit"></a>')


#url <- 'https://github.com/liao961120/parallelCode/edit/master/'
#gh_edit_path <- paste0(url, knitr::current_input())

# edit_btn <- paste0('<a href="', gh_edit_path, '">',
#                    '<img src="https://bit.ly/2RRirG7" ',
#                    'alt="fa-edit" ',
#                    'class="edit"></a>')

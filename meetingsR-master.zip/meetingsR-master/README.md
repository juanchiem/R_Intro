# R meetings and conferences
[![Build Status](https://travis-ci.org/jumpingrivers/meetingsR.png?branch=master)](https://travis-ci.org/jumpingrivers/meetingsR) 

This site attempts to list R conferences and local useR groups. Please 
feel free to add any missing group or conference. 

To propose a change, just click the pencil icon
in the top left hand corner of the [web](https://jumpingrivers.github.io/meetingsR/) 
version.

Keep up to date with [\@rstats_meetings](https://twitter.com/rstats_meetings) 

---

This page is maintained by [\@jumping_uk](https://twitter.com/jumping_uk) 
